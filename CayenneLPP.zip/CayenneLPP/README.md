# CayenneLPP

This is an Arduino Library for Arduino Compatible with Cayenne Low Power Payload

## Documentation

* [Cayenne Low Power Payload](https://mydevices.com/cayenne/docs/#lora-cayenne-low-power-payload)
* [API](https://github.com/sabas1080/CayenneLPP/blob/master/API.md)

Based in the work of [Johan Stokking](https://github.com/TheThingsNetwork/arduino-device-lib)
